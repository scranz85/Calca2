package com.calcador.app

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {

    private var locked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La imagen ocupa siempre toda la pantalla (también bajo las barras),
        // así lo que ves al editar es exactamente lo que ves al calcar.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme {
                CalcaApp(locked = locked, onLockChange = ::setLocked)
            }
        }
    }

    private fun setLocked(value: Boolean) {
        if (locked == value) return
        locked = value
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (value) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setBrightness(1f)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            // Fija la pantalla: bloquea gestos de inicio/recientes/notificaciones.
            // Android pide confirmación al usuario la primera vez.
            try { startLockTask() } catch (_: Exception) {}
        } else {
            try { stopLockTask() } catch (_: Exception) {}
            controller.show(WindowInsetsCompat.Type.systemBars())
            setBrightness(WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE)
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun setBrightness(value: Float) {
        val lp = window.attributes
        lp.screenBrightness = value
        window.attributes = lp
    }

    // Con el bloqueo activo nos tragamos todos los toques.
    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean =
        if (locked) true else super.dispatchTouchEvent(ev)

    // Con el bloqueo activo, vol+ o vol- desbloquean.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (locked &&
            (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) setLocked(false)
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
