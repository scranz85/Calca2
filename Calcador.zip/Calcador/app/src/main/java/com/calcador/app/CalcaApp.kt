package com.calcador.app

import android.content.Context
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** Estado de edición de la imagen. */
data class EditState(
    val scale: Float = 1f,
    val rotation: Float = 0f,          // grados
    val offset: Offset = Offset.Zero,  // píxeles
    val mirror: Boolean = false,
    val gray: Boolean = false,
    val invert: Boolean = false,
    val brightness: Float = 0f,        // -1..1
    val contrast: Float = 1f,          // 0.5..2
    val alpha: Float = 1f,             // opacidad 0.1..1
    val whiteBg: Boolean = true,
) {
    /** Gris -> contraste/brillo -> invertir, combinado en una sola matriz 4x5. */
    fun colorFilter(): ColorFilter {
        val m = ColorMatrix().apply { if (gray) setToSaturation(0f) }.values.copyOf()
        val s = if (invert) -contrast else contrast
        val tBase = 128f * (1f - contrast) + brightness * 255f
        val t = if (invert) 255f - tBase else tBase
        for (row in 0..2) {
            for (col in 0..4) m[row * 5 + col] *= s
            m[row * 5 + 4] += t
        }
        return ColorFilter.colorMatrix(ColorMatrix(m))
    }
}

private fun Float.norm180() = ((this + 180f) % 360f + 360f) % 360f - 180f

fun loadBitmap(context: Context, uri: Uri): ImageBitmap? = try {
    val source = ImageDecoder.createSource(context.contentResolver, uri)
    ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val biggest = maxOf(info.size.width, info.size.height)
        if (biggest > 2048) decoder.setTargetSampleSize(biggest / 2048)
    }.asImageBitmap()
} catch (e: Exception) {
    null
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CalcaApp(locked: Boolean, onLockChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }
    var st by remember { mutableStateOf(EditState()) }
    var panelOpen by remember { mutableStateOf(true) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            loadBitmap(context, uri)?.let {
                bitmap = it
                st = EditState(whiteBg = st.whiteBg)
            }
        }
    }
    val pickImage = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (st.whiteBg) Color.White else Color.Black)
    ) {
        // Capa de imagen (mismo tamaño en edición y en bloqueo)
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(locked) {
                    if (!locked) {
                        detectTransformGestures { _, pan, zoom, rot ->
                            val dir = if (st.mirror) -1f else 1f
                            st = st.copy(
                                scale = (st.scale * zoom).coerceIn(0.05f, 10f),
                                rotation = (st.rotation + rot * dir).norm180(),
                                offset = st.offset + pan,
                            )
                        }
                    }
                }
        ) {
            val bmp = bitmap
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    alpha = st.alpha,
                    colorFilter = st.colorFilter(),
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            translationX = st.offset.x
                            translationY = st.offset.y
                            scaleX = st.scale * (if (st.mirror) -1f else 1f)
                            scaleY = st.scale
                            rotationZ = st.rotation
                        }
                )
            } else if (!locked) {
                Text(
                    "Elige una imagen para empezar",
                    color = if (st.whiteBg) Color.Black else Color.White,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        if (!locked) {
            FilledTonalButton(
                onClick = { panelOpen = !panelOpen },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(8.dp)
            ) { Text(if (panelOpen) "Ocultar panel" else "Panel") }

            if (panelOpen) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    tonalElevation = 3.dp,
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                ) {
                    Column(
                        Modifier
                            .verticalScroll(rememberScrollState())
                            .navigationBarsPadding()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { pickImage() }) { Text("Elegir imagen") }
                            OutlinedButton(
                                enabled = bitmap != null,
                                onClick = { st = st.copy(rotation = (st.rotation + 90f).norm180()) }
                            ) { Text("Girar 90°") }
                            TextButton(onClick = { st = EditState(whiteBg = st.whiteBg) }) {
                                Text("Restablecer")
                            }
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = st.mirror,
                                onClick = { st = st.copy(mirror = !st.mirror) },
                                label = { Text("Espejo") })
                            FilterChip(
                                selected = st.gray,
                                onClick = { st = st.copy(gray = !st.gray) },
                                label = { Text("Grises") })
                            FilterChip(
                                selected = st.invert,
                                onClick = { st = st.copy(invert = !st.invert) },
                                label = { Text("Invertir") })
                            FilterChip(
                                selected = st.whiteBg,
                                onClick = { st = st.copy(whiteBg = !st.whiteBg) },
                                label = { Text("Fondo blanco") })
                        }

                        LabeledSlider("Tamaño", st.scale, 0.05f..5f) { st = st.copy(scale = it) }
                        LabeledSlider("Rotación", st.rotation.norm180(), -180f..180f) {
                            st = st.copy(rotation = it)
                        }
                        LabeledSlider("Brillo", st.brightness, -1f..1f) { st = st.copy(brightness = it) }
                        LabeledSlider("Contraste", st.contrast, 0.5f..2f) { st = st.copy(contrast = it) }
                        LabeledSlider("Opacidad", st.alpha, 0.1f..1f) { st = st.copy(alpha = it) }

                        Button(
                            enabled = bitmap != null,
                            onClick = { onLockChange(true) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Bloquear y calcar (vol + / vol − para desbloquear)") }
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Text(label, style = MaterialTheme.typography.labelMedium)
    Slider(
        value = value.coerceIn(range.start, range.endInclusive),
        onValueChange = onChange,
        valueRange = range
    )
}
